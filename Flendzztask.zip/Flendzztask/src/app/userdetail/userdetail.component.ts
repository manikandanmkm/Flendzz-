import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { UserserviceService } from '../users/userservice.service'
@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {
temp;
userdetails;
  constructor( private user: UserserviceService, private route:ActivatedRoute) { }

  ngOnInit(): void {

    this.temp = localStorage.getItem('loc');

    this.userdet(this.temp)
  }
userdet(id){
  this.user.get(id).subscribe(data=>{
    this.userdetails = data;
    console.log(data);
  })
}


}
