import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {UserserviceService } from './userservice.service'
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
user;
userdetail;
val;
  constructor( private userservice: UserserviceService, private route: Router) { }

  ngOnInit(): void {

    this.userservice.getall().subscribe(data=>{
      this.user = data;
      console.log(data);
    })
  }
  getvalue(data){
    localStorage.setItem( 'loc', JSON.stringify(data));
    console.log('UPDATE' , data);
   this.route.navigate(['/userdetail'])
  }
  


}
