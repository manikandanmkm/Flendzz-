import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
  private api="https://jsonplaceholder.typicode.com";
  constructor( private http: HttpClient) { }

  getall(){
    return this.http.get(this.api +'/users')
  }
  get(id){
    return this.http.get(this.api + '/users/'+ id)
  }

}
